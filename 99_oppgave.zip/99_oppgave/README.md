Hei.

## Oppgaven

Du løser den på egne vilkår da du får retting underveis.
Lånte oppgaveteksten fra et kurs jeg tok en gang da jeg likte måten å teste seg på samt får øvd på det man
trenger å kjenne til i moderne JS.

## Ikke rør

Ikke rør det som står under "Don't make changes below this line", da blir det krøll

## Setup

npm install
npm run start

All informasjon knyttet til om du har svart rett / hva som er feil kommer da opp i terminalen. Se også video med demo av første oppgave
